🥗 Food Adulteration Detection Dashboard
TEAM ID: ["148"]
TEAM MEMBERS NAME: TANISHA SHARMA(CSE)
                   PRATYUSHA BEHERA(BCA)
                   ANTARA ADHIKARI(BCA)
                   SUVAM NAHAK(BCA)




🥗 Food Adulteration Detection Dashboard
Team Name: Food Guardians
Team ID: FAD-007

🚀 Project Overview
Food adulteration poses a significant threat to public health, economic stability, and consumer trust. This project introduces an interactive Food Adulteration Detection Dashboard, built with Streamlit, that provides deep insights into common food adulterants, their health risks, and detection methods.

Leveraging a real-world Kaggle dataset, the dashboard allows users to:

Explore specific product adulteration statuses

Analyze health risk and severity

Use an experimental image-based color detection tool to spot visible adulteration

Our solution empowers consumers with information and serves as a preliminary tool for identifying potentially unsafe food, contributing to safer consumption and more transparency in the food supply chain.

✨ Features
🔍 Interactive Product Selection
Choose from a wide list of food items to view their safety status and detailed adulteration data.

🚦 Dynamic Adulteration Status
Automatically classifies products as:

✅ Safe

🟡 Minor Adulteration

🔴 Adulterated
...based on health risk and severity logic.

📊 Detailed Product Analysis
Visual charts (Pie and Bar) display:

Health Risk distribution

Severity levels

Common detection methods

⚙️ Features
✅ Product selection from the dataset (no hardcoded lists)

✅ Smart classification: Safe, Minor Adulteration, or Adulterated

✅ Charts for:

Health Risk Distribution

Severity Levels

Detection Methods

✅ Full searchable dataset viewer

✅ Responsive UI with emoji indicators

✅ Clean layout and branding

📸 Color Detection Tool
📊 Average color comparison with safe ranges
🧪 Simulates real-world food testing through:

1️⃣ Click to Detect Color
Upload a food sample image and click to detect its pixel color.

2️⃣ Automatic Color Safety Check
Checks average color tone against safe reference ranges.

3️⃣ Color Strip Matching
Shows closest color category and alerts if it indicates possible adulteration.

Automatically detect and display the average color (Hex & RGB).

Compare against safe reference colors.

Suggests if color indicates possible adulteration.

Simulated color strip matching included.



🛠️ Technologies Used

Library	        Purpose
Python 3.x  	Core programming language
Streamlit   	Web app framework
Pandas      	Data processing and cleaning
Plotly	        Interactive visualizations
Pillow (PIL)	Image uploading and preprocessing
Numpy	        Array and image analysis support
OpenCV (cv2)	Image color extraction and comparison





