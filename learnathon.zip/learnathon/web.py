import streamlit as st 
import pandas as pd
import plotly.express as px
from PIL import Image
import numpy as np
import cv2

# 1. Set the page layout
st.set_page_config(page_title="Food Adulteration Dashboard", layout="wide")

# 2. Load the Kaggle dataset
try:
    df = pd.read_csv("food_adulteration_data.csv")
except FileNotFoundError:
    st.error("❌ CSV file not found! Please place 'food_adulteration_data.csv' in the same folder.")
    st.stop()

# Clean column names and values
df.columns = [col.strip().lower().replace(" ", "_") for col in df.columns]
df["adulterant"] = df["adulterant"].astype(str).str.strip().str.lower()
df["product_name"] = df["product_name"].astype(str).str.strip()
df["product_name_clean"] = df["product_name"].str.lower()

# 3. Show page title
st.markdown("<h1 style='text-align:center; color:green;'>🥗 Food Adulteration Detection Dashboard</h1>", unsafe_allow_html=True)

# 4. Sidebar - Product selection from full product list
st.sidebar.header("🔎 Select a Product")

def classify_product_status(product_df):
    risk_mode = product_df['health_risk'].dropna().str.lower().mode()
    if not risk_mode.empty:
        main_risk = risk_mode[0]
        if "high" in main_risk:
            return "Adulterated"
        elif "medium" in main_risk or "moderate" in main_risk:
            return "Minor Adulteration"
        else:
            return "Safe"
    else:
        return "Safe"

# Categorize products
classified_products = {"Safe": [], "Minor Adulteration": [], "Adulterated": []}
for product in df["product_name"].dropna().unique():
    product_df = df[df["product_name"].str.lower() == product.lower()]
    category = classify_product_status(product_df)
    classified_products[category].append(product)

# Dropdown with emoji tags
all_classified_products = (
    ["🟢 Safe: " + p for p in classified_products["Safe"]] +
    ["🟡 Minor: " + p for p in classified_products["Minor Adulteration"]] +
    ["🔴 Adulterated: " + p for p in classified_products["Adulterated"]]
)
selected_label = st.sidebar.selectbox("Choose a product", sorted(all_classified_products))
selected_product = selected_label.split(": ")[-1]

# 5. Product status logic
matches = df[df['product_name_clean'] == selected_product.lower()]
risk_mode = matches['health_risk'].dropna().str.lower().mode()

if not risk_mode.empty:
    main_risk = risk_mode[0]
    if "high" in main_risk:
        status = "Adulterated"
        color = "#ffcccc"
        message = "🔴 <b>Adulterated</b><br>Detected with HIGH health risk."
    elif "medium" in main_risk or "moderate" in main_risk:
        status = "Minor Adulteration"
        color = "#fff3cd"
        message = "🟡 <b>Minor Adulteration</b><br>Detected with MEDIUM or MODERATE health risk."
    else:
        status = "Safe"
        color = "#ccffcc"
        message = "🟢 <b>Safe</b><br>No significant health risks found."
else:
    status = "Safe"
    color = "#ccffcc"
    message = "🟢 <b>Safe</b><br>No reports of adulteration found."

# 6. Display selected product + status
col1, col2 = st.columns(2)
with col1:
    st.markdown("### 🍽 Selected Product")
    st.success(selected_product)
with col2:
    st.markdown("### 🧪 Adulteration Status")
    st.markdown(f"<div style='background-color:{color}; padding:15px; border-radius:10px;'>{message}</div>", unsafe_allow_html=True)

# 7. Divider
st.markdown("---")

# 8. Charts for Selected Product
st.markdown("## 📊 Selected Product Analysis")

if not matches.empty:
    col3, col4 = st.columns(2)

    with col3:
        pie_data_selected = matches['health_risk'].value_counts()
        fig_selected = px.pie(
            names=pie_data_selected.index,
            values=pie_data_selected.values,
            title=f"Health Risk in '{selected_product}'",
            color=pie_data_selected.index,
            color_discrete_map={"Low": "green", "Medium": "orange", "Moderate": "orange", "High": "red"}
        )
        st.plotly_chart(fig_selected, use_container_width=True)

    with col4:
        bar_severity = matches['severity'].value_counts()
        fig_severity = px.bar(
            x=bar_severity.index,
            y=bar_severity.values,
            title=f"Severity Levels in '{selected_product}'",
            labels={'x': 'Severity', 'y': 'Count'},
            color=bar_severity.index,
            color_discrete_sequence=px.colors.sequential.OrRd
        )
        st.plotly_chart(fig_severity, use_container_width=True)

    st.markdown("### 🔬 Detection Methods Used")
    method_counts = matches['detection_method'].value_counts()
    if not method_counts.empty:
        fig_method = px.bar(
            x=method_counts.index,
            y=method_counts.values,
            title=f"Detection Methods for '{selected_product}'",
            labels={'x': 'Detection Method', 'y': 'Count'},
            color=method_counts.index,
            color_discrete_sequence=px.colors.qualitative.Set2
        )
        st.plotly_chart(fig_method, use_container_width=True)
else:
    st.info("ℹ️ No data available for the selected product.")

# 9. Optional Overall Summary
st.markdown("## 📈 Overall Dataset Summary (Optional)")
show_overall = st.checkbox("Show overall dataset summary")

if show_overall:
    col5, col6 = st.columns(2)

    with col5:
        overall_risks = df['health_risk'].value_counts()
        fig_all_risks = px.pie(
            names=overall_risks.index,
            values=overall_risks.values,
            title="Overall Health Risk Distribution",
            color=overall_risks.index,
            color_discrete_map={"Low": "green", "Medium": "orange", "Moderate": "orange", "High": "red"}
        )
        st.plotly_chart(fig_all_risks, use_container_width=True)

    with col6:
        pie_data_category = df['category'].value_counts()
        fig2 = px.pie(
            names=pie_data_category.index,
            values=pie_data_category.values,
            title="Product Category Distribution",
            color_discrete_sequence=px.colors.qualitative.Set3
        )
        st.plotly_chart(fig2, use_container_width=True)

# 10. Search bar
st.markdown("## 🔍 Search and Explore the Dataset")
search_term = st.text_input("Search for any product, brand, or category:")

if search_term:
    filtered_df = df[df.apply(lambda row: search_term.lower() in str(row).lower(), axis=1)]
    st.dataframe(filtered_df, use_container_width=True)
else:
    st.dataframe(df, use_container_width=True)

# 11. Color Detection Tool
st.markdown("---")
st.markdown("## 🎨 Color Detection Tool (Image Based)")

uploaded_image = st.file_uploader("Upload an image of the food item (e.g., turmeric, tea, etc.)", type=["jpg", "jpeg", "png"])

if uploaded_image:
    st.image(uploaded_image, caption="Uploaded Image", use_column_width=True)
    image = Image.open(uploaded_image).convert("RGB")
    img_array = np.array(image)
    img_cv = cv2.cvtColor(img_array, cv2.COLOR_RGB2BGR)

    avg_color_per_row = np.average(img_cv, axis=0)
    avg_color = np.average(avg_color_per_row, axis=0).astype(int)
    avg_color_rgb = tuple(reversed(avg_color))
    avg_hex = '#%02x%02x%02x' % avg_color_rgb

    st.markdown(f"**Detected Average Color:** <span style='color:{avg_hex}; font-weight:bold;'>{avg_hex}</span>", unsafe_allow_html=True)
    st.color_picker("Color Sample", value=avg_hex, label_visibility="collapsed")

    def classify_color(product_name, rgb):
        product_name = product_name.lower()
        r, g, b = rgb
        if "turmeric" in product_name:
            if r > 180 and g > 130 and b < 100:
                return "🟢 Natural turmeric color"
            else:
                return "🔴 Unnatural turmeric color (Possible lead chromate)"
        elif "tea" in product_name:
            if r < 100 and g < 100 and b < 100:
                return "🟢 Natural tea color"
            else:
                return "🔴 Bright tea color (Possible artificial coloring)"
        else:
            return "ℹ️ No color reference available for this product"

    if selected_product:
        classification = classify_color(selected_product, avg_color_rgb)
        st.info(classification)

    st.markdown("### 🎨 Reference Color Strip (Example)")
    st.markdown(
        """
        <div style="display:flex;">
            <div style="width:60px; height:30px; background:#f4c542; border:1px solid black;"></div>
            <div style="width:60px; height:30px; background:#ffcc00; border:1px solid black;"></div>
            <div style="width:60px; height:30px; background:#ffa500; border:1px solid black;"></div>
            <div style="margin-left:10px;">Turmeric safe range</div>
        </div>
        """, unsafe_allow_html=True
    )

# 12. Footer
st.markdown("---")
st.markdown("<p style='text-align:center;'>Made with ❤ by <strong>Tanisha Sharma</strong> | Powered by Real Kaggle Data</p>", unsafe_allow_html=True)
